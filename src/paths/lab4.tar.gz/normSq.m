function [ d ] = normSq(a)
d = a(:,1).^2 + a(:,2).^2;
end

