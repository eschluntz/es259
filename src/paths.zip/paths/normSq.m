function [ d ] = normSq(a)
d = dot(a,a);
end

