function [ r ] = d2r( d )
%d2r degrees to radians
r = d / 180 * pi;
end

