function [ z ] = get_z( T )
%UNTITLED5 Summary of this function goes here
z = T(1:3,3);


end

