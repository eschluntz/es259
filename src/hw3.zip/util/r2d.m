function [ d ] = r2d( r )
%r2d radians to degrees
d = r / pi * 180;
end
